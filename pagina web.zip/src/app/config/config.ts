// PROD http://www.lucreciaurbano.com.ar/public/index.php/api/palabraRandFilter

// TEST http://127.0.0.1:8000/

export const URL_SERVICIOS = "http://www.lucreciaurbano.com.ar/public/index.php/";
