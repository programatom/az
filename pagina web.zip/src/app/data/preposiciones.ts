export const PREPOSICIONES =
[
  "a","ante","bajo","con","contra","de","desde",
  "durante","en","entre","hacia","hasta","para",
  "por","segun","sin","sobre","tras","durante"
]
