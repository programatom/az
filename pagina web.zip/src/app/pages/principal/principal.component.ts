import { Component, OnInit } from '@angular/core';
import { ProcesadorApiService, ProcesadorFraseDetService } from 'src/app/services/service.index';
import TypeIt from 'typeit';
import swal from "sweetalert"

declare function initPlugin();
declare function addRemoveActive(arg);

@Component({
  selector: 'app-principal',
  templateUrl: './principal.component.html',
  styleUrls: ['./principal.component.css']

})
export class PrincipalComponent implements OnInit {

  palabra: string = "";
  showLoader = false;

  stringFrases: string = "";
  fraseNueva = "";
  fraseTypeada = "";

  typingAudio = new Audio();
  timeOutFrase:any;
  stopAnimation = false;

  constructor(private procesadorApi: ProcesadorApiService,
    private procesadorFraseDetServ: ProcesadorFraseDetService) {

  }


  filtrarPalabra(palabra) {

    if (typeof palabra != "string") {
      return false;
    };
    if (palabra == "") {
      return false;
    }

    if (palabra.split(" ").length > 1) {
      swal("Solo se puede enviar una palabra..")
      return false;
    }
    return true;
  }

  enviarPalabra(palabra: string) {

    this.palabra = "";
    if (this.filtrarPalabra(palabra) == false) {
      console.log("error de tipo")
      return;
    }
    addRemoveActive("remove");

    this.showLoader = true;
    this.procesadorApi.apiCallPalabra(palabra).subscribe((respuestaServidor) => {
      addRemoveActive("add");
      this.showLoader = false;
      console.log(respuestaServidor);
      if (respuestaServidor == null) {
        console.log("No se reconocio la palabra")
      }
      (err) => {
        this.showLoader = false;
        console.log("Error de servidor");
        console.log(err);
      }
    })
  }

  generarFrase() {

    if(this.stopAnimation){
      return;
    }

    this.procesadorFraseDetServ.generarFrase().then((frase: any) => {
      console.log(frase)

      if(this.stopAnimation){
        return;
      }
      this.fraseNueva = frase;
      this.nuevaInstanciaDeType();
    })
    .catch(() => {
      console.log("No se encontró una palabra de la frase..");
      this.generarFrase();
    });

  }

  nuevaInstanciaDeType(){

    if(this.stopAnimation){
      return;
    }

    this.stringFrases = this.stringFrases + this.fraseTypeada;
    this.typingAudio.play().catch((err)=>{
      console.log(err);
      this.initAudio();
    }).then(()=>{
      console.log("Se dio al play con éxito");
    })
    let interval = setInterval(()=>{
      if(this.typingAudio.ended){
        console.log("Se termina el audio antes de que se termine de tipear")
        this.typingAudio.play();
        clearInterval(interval);
      }
    },100);
    const instance = new TypeIt('#frases',{
      lifeLike: true,
      strings: this.fraseNueva,
      afterComplete: () => {
        if(this.stopAnimation){
          return;
        }
        clearInterval(interval);
        this.typingAudio.pause();
        console.log("Se termina de tipear");
        this.fraseTypeada = this.fraseNueva;
        this.timeOutFrase = setTimeout(()=>{
          this.generarFrase();
        },3000)
 },
    }).go();
  }

  frenarAnimacion(){
    clearTimeout(this.timeOutFrase);
    this.stopAnimation = true;
    this.typingAudio.pause();
  }

  initAudio(){
    this.typingAudio = new Audio();
    this.typingAudio.src = "../../../assets/audio/typewriter-1.mp3";
    this.typingAudio.volume = 0.6;
    this.typingAudio.load();
  }



  ngOnInit() {
    this.initAudio();
    initPlugin();
    setTimeout(()=>{
      this.generarFrase()
    },6000);


  }

}
