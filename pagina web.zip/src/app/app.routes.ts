import { Routes, RouterModule } from "@angular/router";



const appRoutes:Routes = [

]

export const APP_ROUTES = RouterModule.forRoot( appRoutes, {useHash: true});
