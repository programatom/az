export { ProcesadorFraseDetService } from './procesador-frase-det/procesador-frase-det.service';
export { ProcesadorApiService } from "./procesador-api/procesador-api.service";
